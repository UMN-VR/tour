import type { SettingsRegistry } from "@foss-earth/ui/settings";
import type { ImageryTuning } from "../babylon/imagery/createImageryRuntime.js";
import type { ImageryResourceLimits } from "../terrain/imagery/imageryResidency.js";

const MiB = 1024 * 1024;

/** The parameters that bound imagery work: a change applies at the next update. */
export const IMAGERY_LIMIT_IDS = [
  "map.imagery.gpuBudget",
  "map.imagery.stagingBudget",
  "map.imagery.concurrentRequests",
  "map.imagery.queuedRequests",
  "map.imagery.uploadPerFrame",
  "map.imagery.selectionTimePerFrame",
  "map.imagery.missingRetryAfter",
  "map.retryDelay",
] as const;

/** The parameters that tune how imagery is chosen and drawn. */
export const IMAGERY_TUNING_IDS = [
  "map.imagery.reselectWhileMoving",
  "map.imagery.anisotropy",
  "map.imagery.fallbackGap",
  "map.imagery.fallbackStep",
  "map.imagery.pageTablePatches",
  "map.imagery.maxNodes",
  "map.imagery.refineAbove",
  "map.imagery.coarsenBelow",
  "map.imagery.coarsenAfter",
  "map.imagery.pinFor",
] as const;

function number(settings: SettingsRegistry, id: string): number {
  const value = settings.get(id);
  if (typeof value !== "number") throw new Error(`${id} is not a number.`);
  return value;
}

/** A range in seconds, in ms. */
function seconds(settings: SettingsRegistry, id: string): { min: number; max: number } {
  const value = settings.get(id);
  if (typeof value !== "object" || value === null || !("min" in value)) throw new Error(`${id} is not a range.`);
  return { min: value.min * 1000, max: value.max * 1000 };
}

export function imageryLimitsFrom(settings: SettingsRegistry): ImageryResourceLimits {
  return {
    gpuBytes: number(settings, "map.imagery.gpuBudget") * MiB,
    stagingBytes: number(settings, "map.imagery.stagingBudget") * MiB,
    concurrentRequests: Math.round(number(settings, "map.imagery.concurrentRequests")),
    queuedRequests: Math.round(number(settings, "map.imagery.queuedRequests")),
    uploadBytesPerUpdate: number(settings, "map.imagery.uploadPerFrame") * MiB,
    cpuMsPerUpdate: number(settings, "map.imagery.selectionTimePerFrame"),
    missingRetryMs: number(settings, "map.imagery.missingRetryAfter") * 1000,
    retryDelayMs: seconds(settings, "map.retryDelay"),
  };
}

export function imageryTuningFrom(settings: SettingsRegistry): ImageryTuning {
  return {
    reselectWhileMovingMs: number(settings, "map.imagery.reselectWhileMoving"),
    anisotropy: Math.round(number(settings, "map.imagery.anisotropy")),
    fallbackGap: Math.round(number(settings, "map.imagery.fallbackGap")),
    fallbackStep: Math.round(number(settings, "map.imagery.fallbackStep")),
    tablePatches: Math.round(number(settings, "map.imagery.pageTablePatches")),
    maxNodes: Math.round(number(settings, "map.imagery.maxNodes")),
    hysteresis: {
      refineAbove: number(settings, "map.imagery.refineAbove"),
      coarsenBelow: number(settings, "map.imagery.coarsenBelow"),
      coarsenAfterMs: number(settings, "map.imagery.coarsenAfter"),
      pinMs: number(settings, "map.imagery.pinFor"),
    },
  };
}
